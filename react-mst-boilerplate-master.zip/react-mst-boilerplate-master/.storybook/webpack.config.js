const webpackConfig = require("react-scripts-ts/config/webpack.config.dev");

module.exports = webpackConfig;
