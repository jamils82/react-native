export default interface SizePropType {
  uiSize?: "s" | "m" | "l" | "xs" | "xl" | "xxs" | "xxl" | number;
};
