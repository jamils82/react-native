const en = require("./en");
const fr = require("./fr");

export default {
    en,
    fr,
};