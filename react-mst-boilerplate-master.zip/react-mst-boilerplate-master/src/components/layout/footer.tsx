import * as React from "react";

const Footer = () => (
    <div />
);
export default Footer;
