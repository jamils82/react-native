export default interface BackgroundPropType {
  uiBackground?: number | string;
}
