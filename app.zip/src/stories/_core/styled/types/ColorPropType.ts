export default interface ColorPropType {
  uiColor?: number | string;
};
