const keys = {
    user: "user"
};
export default keys;