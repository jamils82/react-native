export const API_HOST = "https://dog.ceo/api/";
export const URLs = {
    allBreads: "breeds/list/all"
};