import Boot from "./services/Boot";
import "font-awesome/css/font-awesome.min.css";

new Boot();
